
public class FloatMecanics {

	public static void main(String[] args)
	{
		int a, b;
		float c;
		
		a = 5;
		b = 2;
		c = a/b;
		System.out.println(c);
	}
	
}

import java.util.Scanner;
import java.util.ArrayList;

public class Results2
{

	private int phy, che, mat, numFailures;
	private float total, per;

	Scanner scanner = new Scanner(System.in);

	ArrayList failedSubjects = new ArrayList();

	public void showResults()
	{
		total = phy + che + mat;

		numFailures = failedSubjects.size();

		switch (numFailures)
		{
		case 0:
			per = (float) total * 100 / 450;
			System.out.println("Well done, you are smart.");
			System.out.println("Total score = " + total);
			System.out.println("Total percentage = " + per);
			break;

		case 1:
			System.out.println("Retake " + failedSubjects.get(0) + " exam.");
			break;

		case 2:
			System.out.println("You failed both " + failedSubjects.get(0) + " and " + failedSubjects.get(1)
					+ ", retake the course.");
			break;

		case 3:
			System.out.println("All 3 exams failed. Go home.");
			break;
		}
		scanner.close();
	}

	public void SetPhysics()
	{
		boolean resultValid = false;
		System.out.println("Please enter a physics mark: ");

		while (resultValid == false)
		{
			while (!scanner.hasNextInt())
			{
				System.out.println("Not an integer, please enter an integer");
				scanner.next();
			}
			int a = scanner.nextInt();
			if (a >= 0 && a <= 150)
			{
				phy = a;
				if (a < 70)
				{
					failedSubjects.add("Physics");
				}
				resultValid = true;
			} else
			{
				System.out.println("Sorry, invalid physics result input");
				resultValid = false;
			}
		}
	}

	public void SetChemistry()
	{
		boolean resultValid = false;
		System.out.println("Please enter a chemistry mark: ");

		while (resultValid == false)
		{
			while (!scanner.hasNextInt())
			{
				System.out.println("Not an integer, please enter an integer");
				scanner.next();
			}
			int a = scanner.nextInt();
			if (a >= 0 && a <= 150)
			{
				che = a;
				if (a < 70)
				{
					failedSubjects.add("Chemistry");
				}
				resultValid = true;
			} else
			{
				System.out.println("Sorry, invalid chemistry result input");
				resultValid = false;
			}
		}
	}

	public void SetMaths()
	{
		boolean resultValid = false;
		System.out.println("Please enter a maths mark: ");

		while (resultValid == false)
		{
			while (!scanner.hasNextInt())
			{
				System.out.println("Not an integer, please enter an integer");
				scanner.next();
			}
			int a = scanner.nextInt();
			if (a >= 0 && a <= 150)
			{
				mat = a;
				if (a < 70)
				{
					failedSubjects.add("Maths");
				}
				resultValid = true;
			} else
			{
				System.out.println("Sorry, invalid maths result input");
				resultValid = false;
			}
		}
	}
}

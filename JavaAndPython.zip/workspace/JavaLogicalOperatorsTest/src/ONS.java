
public class ONS {

	
	public static void main(String[] args)
	{

		Results2 John;
		
		John = new Results2();
		
		John.SetChemistry();
		John.SetMaths();
		John.SetPhysics();

		John.showResults();
	}
}


public class IF {

	
	public static void main(String[] args)
	{
	int a = 15;
	String b = "False";
	
	if(a<2)
		System.out.println("True");
	else
		System.out.println(b);	
	}
}

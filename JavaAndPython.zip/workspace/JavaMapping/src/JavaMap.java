
public class JavaMap
{
	int sizeOfArrays = 10;
	int[] mapKeyArray = new int[sizeOfArrays];
	String[] mapValueArray = new String[sizeOfArrays];
	int currentIndex = 0, currentNumStored = 0;

	public void add(int key, String value)
	{
		if (currentIndex < sizeOfArrays)
		{
			mapKeyArray[currentIndex] = key;
			mapValueArray[currentIndex] = value;
			currentIndex++;
		} else
		{
			System.out.println("Arrays are full.");
		}
	}

	public void remove(int key)
	{
		for (int i = 0; i < sizeOfArrays; i++)
		{
			if (key == mapKeyArray[i])
			{
				mapValueArray[i] = " ";
				currentIndex = i;
			}
		}
	}

	public void searchKey(int key)
	{
		for (int i = 0; i < sizeOfArrays; i++)
		{
			if (key == mapKeyArray[i])
			{
				System.out.println("Key " + key + " has value " + mapValueArray[i]);
			}
		}
	}

	public void searchKey(String value)
	{
		for (int i = 0; i < sizeOfArrays; i++)
		{
			if (mapValueArray[i].equals(value))
			{
				System.out.println("Value " + value + " belongs to key " + mapKeyArray[i]);
			}
		}
	}
	
	public void mapKey(int key, String value)
	{
		for(int i = 0; i < sizeOfArrays; i++)
		{
			if(mapKeyArray[i] == key)
			{
				mapValueArray[i] = value;
			}
		}
	}

}


public class JavaMain
{
	public static void main(String[] args)
	{
		JavaMap map = new JavaMap();
		
		map.add(10, "Hello");
		map.add(56, "My");
		map.add(2, "name");
		map.add(9, "is");
		map.add(98, "James");
		map.searchKey(2);
		map.mapKey(98, "Felicity");
		map.searchKey(98);
	}
}

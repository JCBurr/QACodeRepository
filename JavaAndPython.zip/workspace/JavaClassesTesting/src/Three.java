
public class Three {

	float a, b, c;
	
	public void outputFloats()
	{
		System.out.println(a + ", " + b + ", " + c);
	}
	
}


public class One {

	int a, b, c;
	
	public void sayHi()
	{
		System.out.println("Hi");
	}
}

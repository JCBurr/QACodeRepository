
public class Results {

	int phy, che, mat;
	
	float total, per;
	
	public void calculate()
	{
		total = phy + che + mat;
		per = total * 100 / 300;
	}
	
	public void showResults()
	{
		System.out.println(per + "%");
	}
	
}

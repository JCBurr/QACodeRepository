
public class QA {

	public static void main(String[] args)
	{
	
	Results james;
	james = new Results();
	
	james.che = 70;
	james.phy = 65;
	james.mat = 67;
	
	james.calculate();
	james.showResults();
	
	}
	
}


public class Math2 extends MathA
{
	public int multiplication(int a, int b)
	{
		return a * b;
	}
}

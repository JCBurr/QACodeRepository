
public class JavaMain
{
	public static void main(String[] args)
	{
		MathA reference = new Math2();
		System.out.println(reference.addition(1, 2));
	}
}


public class main 
{
	public static void main(String[] args)
	{
		TimesTable.printTimesTable(5, 10);
	}
}

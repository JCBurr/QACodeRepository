import java.text.DecimalFormat;

public class MoneyChange
{

	public static void main(String[] args)
	{

		float paid = 100.03f;
		float bill = 100.00f;
		float currentVal;
		float currentCurrencyVal;
		float numCurrencyUnits;
		int currencyUnits;
		float changeDue = 0.0f;
		float changeArray[] = new float[12];
		int i = 0;
		DecimalFormat df = new DecimalFormat("#.00");

		changeArray[0] = 50.00f;
		changeArray[1] = 20.00f;
		changeArray[2] = 10.00f;
		changeArray[3] = 5.00f;
		changeArray[4] = 2.00f;
		changeArray[5] = 1.00f;
		changeArray[6] = 0.50f;
		changeArray[7] = 0.20f;
		changeArray[8] = 0.10f;
		changeArray[9] = 0.05f;
		changeArray[10] = 0.02f;
		changeArray[11] = 0.01f;

		changeDue = paid - bill;

		String changeDueRounded = df.format(changeDue);
		changeDue = Float.parseFloat(changeDueRounded);
		currentVal = changeDue;
		
		System.out.println("Total change due: �" + changeDue);
		// System.out.println(changeArray[currentVal]);
		while (i < 12)
		{
			currentCurrencyVal = changeArray[i];
			numCurrencyUnits = currentVal / currentCurrencyVal;
			currencyUnits = (int) numCurrencyUnits;
			System.out.println("�" + currentCurrencyVal + " " + currencyUnits);
			currentVal = currentVal % currentCurrencyVal;
			currentVal = Float.parseFloat(df.format(currentVal));
			i++;
		}
	}
}
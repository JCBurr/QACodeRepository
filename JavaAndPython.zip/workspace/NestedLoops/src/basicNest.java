
public class basicNest
{

	public static void runBasicLoop()
	{
		int a = 1, b = 1;

		for (a = 1; a <= 10; a++)
		{
			for (b = 1; b <= 10; b++)
			{
				System.out.println(b);
			}
		}
	}
}

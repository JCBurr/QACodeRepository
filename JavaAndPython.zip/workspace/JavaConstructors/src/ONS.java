
public class ONS 
{
	int x, y;
	public ONS()
	{
		System.out.println("Constructors are fun");
	}
	
	public void message()
	{
		System.out.println("A");
	}
	
}

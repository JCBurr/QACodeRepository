
public class runConstructor {

	public static void main(String[] args)
	{
		ONS x;
		x = new ONS();
	}
}

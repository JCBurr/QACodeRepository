
public class JavaMain
{
	public static void main(String[] args)
	{
	Decryptor.decryptTest("dxu0stu0y?0AI@EAG");
	}
}

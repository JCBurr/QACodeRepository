
public class Circle extends Draw
{
	public void drawing(Draw x)
	{
		System.out.println("Circle");
	}
}

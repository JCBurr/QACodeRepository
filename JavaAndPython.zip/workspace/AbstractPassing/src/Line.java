
public class Line extends Draw
{
	public void drawing(Draw x)
	{
		System.out.println("Line");
	}
}

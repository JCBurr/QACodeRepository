
abstract public class Draw
{
	abstract public void drawing(Draw x);
}

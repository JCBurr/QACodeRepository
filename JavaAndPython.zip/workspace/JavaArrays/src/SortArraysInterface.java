
public interface SortArraysInterface
{
	public void findHighestValue(int[] intArray);

	public void findLowestValue(int[] intArray);

	public void sortArray(int[] intArray);
}

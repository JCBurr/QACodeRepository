import java.util.Scanner;

public class Test
{

	public static void main(String[] args)
	{

		int decisionVariable = 1;
		boolean resolved = false;
		Scanner userInput = new Scanner(System.in);

		System.out.println("Please input first number.");
		int a = userInput.nextInt();

		System.out.println("Please input second number.");
		int b = userInput.nextInt();

		System.out.println("Please enter a value between 1 and 4 inclusive.");

		while (!resolved)
		{
			decisionVariable = userInput.nextInt();
			switch (decisionVariable)
			{
			case 1:
				System.out.println("Addition result of " + a + " and " + b + ": " + Math3.addition(a, b));
				resolved = true;
				break;
			case 2:
				System.out.println("Subtraction result of " + b + " and " + a + ": " + Math3.subtraction(b, a));
				resolved = true;
				break;
			case 3:
				System.out.println("Multiplcation result of " + a + " and " + b + ": " + Math3.multiplication(a, b));
				resolved = true;
				break;
			case 4:
				System.out.println("Division result of " + a + " and " + b + ": " + Math3.division(a, b));
				resolved = true;
				break;
			case 5:
				Math3.printTimesTable(a, b);
				break;
			default:
				System.out.println("Please enter a value between 1 and 4 inclusive.");
				resolved = false;
				break;
			}
		}
		userInput.close();
	}
}

public class Math3 {
	public static float addition(float x, float y) 
	{
		return x + y;
	}

	public static int addition(int x, int y) 
	{
		return x + y;
	}
	
	public static int addition(int x, int y, int z) 
	{
		return x + y + z;
	}

	public static float addition(float x, float y, float z) 
	{
		return x + y + z;
	}
	
	
	public static float subtraction(float x, float y)
	{
		return x - y;
	}

	public static float multiplication(float x, float y) 
	{
		return x * y;
	}

	public static float division(float x, float y) 
	{
		return x / y;
	}
	
	public static void printTimesTable(int t, int r) 
	{
		System.out.println("Times table of " + t + " up to " + r);
		for (int i = 1; i <= r; i++) 
		{
			System.out.println(t + " times " + i + " equals " + (t * i));
		}
	}
}
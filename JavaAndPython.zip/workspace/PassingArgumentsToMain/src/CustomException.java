
public class CustomException extends Exception
{
	public CustomException()
	{
		System.out.println("CustomException has been thrown.");
	}
}

class firstClass():
    def AddValue(self, A, B):
        

public class JavaMain
{
	public static void main(String[] args)
	{
		// WordCounter.outputWords("I am going to London.");
		ReverseWordOrder.reverseOrder("I am going to London.");
		StringCapitaliseAndDouble.alternateStringOutput("ThiuSSGFrhdfzFj7422946.>?");
	}
}

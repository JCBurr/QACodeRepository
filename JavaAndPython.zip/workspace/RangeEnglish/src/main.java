
public class main 
{
	public static void main(String[] args)
	{
		RangeClass range = new RangeClass();
		range.displayRange(4, 9);
	}
}

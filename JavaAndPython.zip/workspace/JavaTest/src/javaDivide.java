
public class javaDivide {
	
	public static void main(String[] args)
	{
		
		int a, b, c;
		
		a = 50;
		b = 10;
		
		c = a/b;
		
		System.out.println(c);
	}

}

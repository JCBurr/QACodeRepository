
public class javaLoopMathematics {

	public static void main(String[] args)
	{
		
		int a = 35;
		
		for(int i = 0; i < a; i++)
		{
			System.out.println("I is currently " + i);
		}
		
	}
	
}


public class javaMultiply {
	
	int a, b, c;
	
	public static void main (String[] args)
	{
		int a = 5;
		int b = 10;
		
		int c = a * b;
		
		System.out.println(c);
	}

}

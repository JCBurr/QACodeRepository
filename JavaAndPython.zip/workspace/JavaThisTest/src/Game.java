
public class Game
{

	int x, y, z;
	
	public void setIntegers()
	{
		this.x = 5;
		this.y = 10;
		this.z = 15;
	}
	
	public void displayIntegers()
	{
		System.out.println("Int x: " + this.x + " Int y: " + this.y + " Int z: " + this.z);
	}
	
}

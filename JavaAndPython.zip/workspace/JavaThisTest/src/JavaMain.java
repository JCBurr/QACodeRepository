
public class JavaMain
{

	public static void main(String[] args)
	{
		
		Game game = new Game();
		
		game.setIntegers();
		game.displayIntegers();
		
	}
	
}

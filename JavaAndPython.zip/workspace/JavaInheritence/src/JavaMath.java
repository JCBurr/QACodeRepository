
public class JavaMath
{
	public static int addition(int x, int y)
	{
		return x + y;
	}
	
	public static int subtraction(int baseValue, int subtractedValue)
	{
		return baseValue - subtractedValue;
	}
	
	final public void displayFinalMessage()
	{
		System.out.println("Final message displayed");
	}
	
}

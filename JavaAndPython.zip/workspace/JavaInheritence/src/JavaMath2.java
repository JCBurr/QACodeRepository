
public class JavaMath2 extends JavaMath
{
	public static int addition(int x, int y)
	{
		System.out.println("The result of the addition of " + x + " and " + y + " is " + (x+y));
		return x + y;
	}
	
	public static float division(float divisor, float dividedBy)
	{
		return divisor / dividedBy;
	}
}

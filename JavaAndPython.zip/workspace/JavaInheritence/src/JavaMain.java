
public class JavaMain
{
	public static void main(String[] args)
	{
		System.out.println(JavaMath2.division(5.0f, 10.0f));
		System.out.println(JavaMath2.addition(1, 9));
		System.out.println(JavaMath.subtraction(10, 7));
		JavaMath2 test = new JavaMath2();
		test.displayFinalMessage();
	}
}

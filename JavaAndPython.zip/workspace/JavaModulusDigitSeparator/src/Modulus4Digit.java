
public class Modulus4Digit {

}

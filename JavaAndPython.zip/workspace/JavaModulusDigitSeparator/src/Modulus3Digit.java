
public class Modulus3Digit {

	public static void modulus3Digits(int num)
	{
		int val1, val2, val3, utilVal;
		
		val1 = num/100;
		utilVal = num%100;
		val2 = utilVal/10;
		val3 = utilVal%10;
		
		System.out.println(val1 + val2 + val3);
	}
}

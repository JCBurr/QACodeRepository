
public class ModulusMain {

	public static void main(String[] args)
	{
		
		Modulus3Digit threeDigit = new Modulus3Digit();
		threeDigit.modulus3Digits(745);
	}
	
}

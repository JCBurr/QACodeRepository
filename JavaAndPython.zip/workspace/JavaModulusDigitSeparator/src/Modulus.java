
public class Modulus {

	public static void twoDigitNumbers(int num)
	{
	
		int val1, val2 = 0;
		
		val1 = num/10;
		val2 = num%10;
		System.out.println(val1+val2);
	}
	
}

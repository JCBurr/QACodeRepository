
public class JavaMain
{
	public static void main(String[] args)
	{
		Binary.decimalToBinary(11);
		Binary.binaryToDecimal("01001");
	}
}

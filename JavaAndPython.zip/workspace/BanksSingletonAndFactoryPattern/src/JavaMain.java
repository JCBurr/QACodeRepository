
public class JavaMain
{
	public static void main(String[] args)
	{
		// Bank HSBC, NatWest, Halifax;
		FourObjectsBank HSBC, NatWest, Halifax, NationWide, NorthernRock;
		HSBC = FourObjectsBank.createBankObject();
		NatWest = FourObjectsBank.createBankObject();
		Halifax = FourObjectsBank.createBankObject();
		NationWide = FourObjectsBank.createBankObject();
		NorthernRock = FourObjectsBank.createBankObject();
	}
}

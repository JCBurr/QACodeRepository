
public class One	//Grandparent class
{
	public One()
	{
		System.out.println("Grandparent constructor called with no arguments.");
	}
}

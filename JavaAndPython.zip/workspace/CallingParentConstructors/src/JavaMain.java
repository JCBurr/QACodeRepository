
public class JavaMain
{
	public static void main(String[] args)
	{
		Three classThree = new Three(9);
		classThree.message();
	}
}

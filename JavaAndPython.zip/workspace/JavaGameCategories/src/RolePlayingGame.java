
public class RolePlayingGame extends ActionGame
{

	@Override
	public void movement()
	{
		System.out.println("Movement method for RPG's: WASD and mouse control.");
	}

}

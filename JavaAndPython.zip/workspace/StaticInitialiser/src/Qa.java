
public class Qa
{
	static int dollar;
	static
	{
		dollar = 15 + 22;
	}

	public Qa()
	{
		dollar += 7;
	}

	int a, b, c;
}

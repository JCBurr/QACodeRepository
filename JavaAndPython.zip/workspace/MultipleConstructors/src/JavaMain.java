
public class JavaMain
{
	public static void main(String[] args)
	{
		QAC test = new QAC(74);
	}
}
